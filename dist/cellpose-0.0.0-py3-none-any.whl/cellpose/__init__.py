from cellpose._version import __version__
from cellpose.version import version, version_str